<?php
	include_once("header.php");
	$h_ti = "";
	$h_ad = "";
	$p_he = "";
	$p_fo = "";
	
	$msg="";
		if( isset($_POST['setsubmit']) ){
		
		$h_title = $_POST['h_title'];
		$h_adress = $_POST['h_adress'];
		$p_header = $_POST['p_header'];
		$p_footer = $_POST['p_footer'];
		$mql = "UPDATE inv_setings SET header_title='".$h_title."', header_adress='".$h_adress."', p_header='".$p_header."', p_footer='".$p_footer."' WHERE id='1' ";
		$res = mysqli_query($link, $mql);
		if($res ){
			$msg="Saved.";
		}else{
			$msg="Something went wrong.";
		}

	}
	
	$mql = "SELECT * FROM inv_setings";
	$res = mysqli_query($link, $mql);
	while( $row = mysqli_fetch_array($res) ){
		$h_ti = $row['header_title'];
		$h_ad = $row['header_adress'];
		$p_he = $row['p_header'];
		$p_fo = $row['p_footer'];
	}

	
 ?>
		<div class="clear"></div>
			<div class="main_body fix">

				<div class="container">
					<form action="" method="post">
						<div class="row fix setings">
							<div class="col-md-12 fix" style="background:#fff; height:50px; margin-top:20px;text-align:center; font-weight:bold;"><?php echo $msg; ?></div>
							<div class="col-md-6 fix" style="background:#fff;" >
								<div class="boxheader"> Header Title </div>
								<div class="set_box">
									<textarea name="h_title" id="" cols="35" rows="2"><?php echo $h_ti; ?></textarea>
								</div>
								<br />
								<div class="boxheader"> Header Address </div>
								<div class="set_box">
									<textarea name="h_adress" id="" cols="35" rows="2"><?php echo $h_ad; ?></textarea>
								</div>
								<br />
							</div>
							
							<div class="col-md-6 fix" style="background:#fff;" >
								<div class="boxheader"> Print Header </div>
								<div class="set_box">
									<textarea name="p_header" id="" cols="35" rows="2"><?php echo $p_he; ?></textarea>
								</div>
								<br />
								<div class="boxheader"> Print Footer </div>
								<div class="set_box">
									<textarea name="p_footer" id="" cols="35" rows="2"><?php echo $p_fo; ?></textarea>
								</div>
								<br />
							</div>
						</div>
						<div class="set_submit">
							<input type="submit" name="setsubmit" value="Save Changes"/>
						</div>
					</form>
			    </div>
			</div>
		</div>
</body>
</html>