<?php
include_once('connection/connect.php');
include_once('functions.php'); 
	$msg="";
	if( isset($_POST['lg_submit']) ){
		$user = $_POST['lg_username'];
		$password = $_POST['lg_password'];
		$password = md5($password);
		$query = "SELECT * FROM `inv_users` WHERE `username` = '".$user."' AND `password` = '".$password."' ";
		$result = mysqli_query($link, $query);
		$row=mysqli_fetch_array($result);
		
		$username = $row['username'];
		$pass = $row['password'];
		$type = $row['type'];
		
		if( strcmp($pass,$password) == 0 && strcmp($user,$username) == 0 && $type == '1' ){

			$_SESSION['user'] = $user;
			$_SESSION['type'] = $type;
			$msg="";
			
			header('location: index.php'); 
		}else{
			$msg="Wrong user name or password!";
		}
		
	
	}

?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Login & Register form</title>
    <link rel="stylesheet" href="css/login.css">
  </head>

  <body>

    <div class="login-wrap">
  <h2>Login</h2>
  <div class="errormsg" ><?php echo $msg; ?></div>
  <div class="form">
  
    <form action="" method="post">
		<input type="text" placeholder="Username" name="lg_username" required />
		<input type="password" placeholder="Password" name="lg_password" required />
		<button type="submit" name="lg_submit" id="login_submit" > Sign in </button>
	</form>
    <a href="#"> <p> Powered by: Selim Reza.</p></a>
  </div>
</div>
    <script src='https://code.jquery.com/jquery-1.10.0.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
