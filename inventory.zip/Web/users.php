<?php
	include_once("header.php");
	if( isset($_GET['u']) ){
		$user = $_GET['u'];
		$mql = "DELETE FROM inv_users WHERE username='".$user."' ";
		 mysqli_query($link, $mql);
	}	
	
 ?>
 	<script type="text/javascript">
		function con_del(){
			return confirm("Are you sure want to delete this user?");
		}
	</script>
	<div class="clear"></div>
	<div class="main_body fix">
		<div class="container">
			<div class="row fix users">
				<div class="col-md-4 fix">
					<div class="usermenu">
						<ul>
							<li><a href="">User List</a></li>
							<li><a href="adduser.php">Add New</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-8 fix userlist">
					<table class="usertable">
						<tr>
							<th>User Name</th>
							<th> User Type </th>
							<th></th>
							<th></th>
						</tr>
						<?php 
						$query = "SELECT * FROM inv_users";
						$result = mysqli_query($link, $query);
						while( $row=mysqli_fetch_array($result) ){
							?>
							<tr>
								<td id="uname"> <?php echo $row['username']; ?> </td>
								<td> <?php if($row['type']=='1'){ echo "Super User"; }else{
									echo "User";
								} ?> </td>
		<td> <a href="#"><button  onclick="showwindow('<?php echo $row['username']; ?>');" >Change Password</button></a> </td>
<td> <a href="?u=<?php echo $row['username']; ?>" onclick="return con_del()" ><button>DELETE</button></a> </td>
							</tr>
								
							<?php
						
						}
						
						?>
						
					</table>
				</div>
			</div>
		</div>
	</div>
	<div id="pop">
		<div class="popinner">
			<div class="cro"><a href="#" id="cross" onclick="document.getElementById('pop').style.display = 'none'">x</a></div>
			<h3>Change Password</h3>
			<br />
			<div id="passmsg"></div>
			<form action="#">
				<table>
					<input type="hidden" name="user_name" id="user_name" value="" />
					<tr>
						<td><label for="inputEmail3" class="">Old Password</label></td>
						<td><input type="password"  id="oldpass" onblur="isPassOk()" /></td>
						<td id="matchinfo" ></td>
					</tr>
					
					<tr>
						<td><label for="inputEmail3" class="">New Password</label></td>
						<td><input type="password"  id="newpass" /></td>
					</tr>
					<tr>
						<td><label for="inputEmail3" class="">Confirm Password</label></td>
						<td><input type="password"  id="conpass" onkeyup="matchpass()" /></td>
						<td><div id="tik"></div></td>
					</tr>
					<tr>
						<td></td>
						<td><input type="button" class="chpass" id="cnpsubmit" value="Change Password"/></td>
						<td></td>
					</tr>
				</table>
			</form>
		</div>
	</div>
	<script type="text/javascript"><!-- Show Window -->
	function showwindow(user){
		document.getElementById('pop').style.display = 'block';
		$('#user_name').val(user);
	}
	
	
	</script>

	
	<script type="text/javascript"> <!-- Password Marching Functions -->
	function isPassOk(){
		var oldpass = $('#oldpass').val();
		var user_name =  $('#user_name').val();
		$.ajax({
			url:'setings/passck.php',
			method:'POST',
			data:{oldpass:oldpass, user_name:user_name},
			success:function(data){
				$('#matchinfo').fadeIn().html(data);
				setTimeout( function(){
					$('#matchinfo').fadeOut('slow');
				},2000 );
			}
		});
	}
	</script>
	
	
	<script type="text/javascript"><!-- Matched Two Fields -->
		function matchpass(){
			var newpass = $('#newpass').val();
			var conpass = $('#conpass').val();
			var t = newpass.localeCompare(conpass);
			if(t==0){
				$('#tik').html('OK');
			}else{
				$('#tik').html('');
			}
			
		}
	</script>
	<script type="text/javascript"><!-- Submit -->
		$(document).ready(function(){
			$("#cnpsubmit").click(function(){
				var user_name =  $('#user_name').val();
				var newpass = $('#newpass').val();
				var conpass = $('#conpass').val();
				var t = newpass.localeCompare(conpass);
				if(t==0){
					$.ajax({
						url:'setings/cngpass.php',
						method:'POST',
						data:{user_name:user_name, newpass:newpass},
						success:function(data){
							$('#passmsg').fadeIn().html(data);
							setTimeout( function(){
								$('#passmsg').fadeOut('slow');
							},2000 );
						}
					});
				}else{
					$('#passmsg').html('Wrong try again.');
				}	
			});
		});
	</script>
	
	

</body>
</html>