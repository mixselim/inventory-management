<?php
	include_once("header.php");

 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page2_main_body fix">

							<h3 style="text-transform: capitalize;" ><?php echo $pro; ?></h3>
							<div style="margin-bottom:50px;"></div>
							<div class="col-md-4 page2_main_body_left fix">

								<h5>Sale</h5>
								<div class="custom">
									<a href="newinvoice.php?tag=<?php echo $pro; ?>"><button>New Invoice</button></a>
								</div>
								<div class="custom">
									<a href="modifyinvoice.php?tag=<?php echo $pro; ?>"><button>Modify Invoice</button></a>
								</div>
								<div class="custom">
									<a href="viewinvoice.php?tag=<?php echo $pro; ?>"><button>View Invoice</button></a>
								</div>
								<div class="custom">
									<button id="del_inbutton" >Delete Invoice</button>
								</div>
								
								<div id="del_invoice">
									<form class="form-horizontal">
								  <div class="form-group">							    
								    <div class="col-sm-10">
								      <input type="text" class="form-control" id="del_id" placeholder="ID No">
								    </div>
								  </div>
								
								  <div class="form-group">
								  
								    <div class="col-sm-10">
								      <input type="text" class="form-control" id="del_memo" placeholder="Memo No">
								    </div>
								    
								  </div>

								   <div class="form-group">
								    
								    <div class="col-sm-10">
								      <button type="button" id="del_del" class="btn btn-default">Delete</button>
								     
								    </div>
									<input type="hidden" id="del_product" value="<?php echo $pro; ?>" />
									
								  </div>

								  
								
								</form>	
								</div>
								<div class="col-sm-10">
									<span id="del_info" ></span>
								</div>

							</div>

							<div class="col-md-5 page2_main_body_middle fix">

								
								<p>
								  <a href="dailyduecollection.php?tag=<?php echo $pro; ?>">
									<button type="button" class="btn btn-primary">Daily Due Colection</button>
									</a>
								</p>
								<p>
									<a href="bkashcollections.php?tag=<?php echo $pro; ?>">
									<button type="button" class="btn btn-primary">Bikash Collection</button>
									</a>
								</p>
								<p>
								  <a href="dailyexpence.php?tag=<?php echo $pro; ?>">
									<button type="button" class="btn btn-primary">Daily Expense</button>
								  </a>
								</p>
						

							</div>

							<div class="col-md-3 page2_main_body_right fix">
								<h5>Report</h5>

								<div class="custom">
									<a href="dailysales.php?tag=<?php echo $pro; ?>"><button>Daily Sales</button></a>
									
								</div>
								<div class="custom">
									<a href="monthlysales.php?tag=<?php echo $pro; ?>"><button>Monthly Sales</button></a>
								</div>
								<div class="custom">
									<a href="yearlysales.php?tag=<?php echo $pro; ?>"><button>Yearly Sales</button></a>
								</div>
								<div class="custom">
									<a href="artfarmlist.php"><button>Artfirm List</button></a>
								</div>

							</div>

						</div>

					</div>

			    </div>
			</div>
	</div>
		<script type="text/javascript" > <!-- Delete Invoice -->
	$(document).ready(function(){
		$("#del_del").click(function(){
			var del_id = $('#del_id').val();
			var del_memo = $('#del_memo').val();
			var del_product = $('#del_product').val();
			if(del_id=='' || del_memo=='' || del_product=='' ){
				$('#del_info').html("All Fields are required.");
			}else{
				var r = confirm("Are you sure want to delete this data?");
				
				if (r == true) {

					$.ajax({
							url:'inc/delinvoice.php',
							method:'POST',
							data:{del_id:del_id, del_memo:del_memo, del_product:del_product},
							success:function(data){
								$('form').trigger('reset');
								$('#del_info').fadeIn().html(data);
								setTimeout( function(){
									$('#del_info').fadeOut('slow');
								},2000 );
							}
						});
				} else {
					
				} 
			}
		});
		
	});	
	</script>

</body>
</html>