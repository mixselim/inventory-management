<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;"><?php echo $pro ?></h3>
							<header class="tableheader">
								<div class="row fix">
									<div class="col-md-6 fix">
										<div class="dailysales">
										<p>
											Daily dues collections.
										</p>
										</div>
									</div>
									<div class="col-md-6 fix">
										<div class="sdate">
											<form action="">
												<input type="date" name="duc_date" id="duc_date" placeholder="yyyy-mm-dd" />
											<input type="button" name="duc_submit" value="View" id="duc_submit" />
											<input type="hidden" value="<?php echo $pro; ?>" id="duc_product" />
											</form>
											<div id="ttt">
												
											</div>
										</div>
									</div>
									
								</div>
							</header>
							<div class="salestable" id="daily_due" >
								<!-- Table Goes here.... -->
				
							<?php
									
								$today = date("Y-m-d");
								
								if( $today!='' ){
								
										$query = "SELECT * FROM inv_ducollections WHERE indate='".$today."' AND products='".$pro."' ";
										?>
											<table>
												<div class="tablef">
												<tr class="sp">
													<th>ID No</th>
													<th>Memo No</th>
													<th>Name</th>
													<th>Taka</th>
												</tr>
												</div>

										<?php
										$result = mysqli_query($link, $query);
										$total_taka=0.0;
										$total_takat = 0.0;
										while( $row=mysqli_fetch_array($result) ){
											$total_taka = $row['dutaka'];
											$total_takat = $total_takat+$total_taka;
											$memo = $row['dumemo'];
										?>
											<tr>
												<td> <?php echo $row['duid']; ?> </td>
												<td> <?php echo $memo ?> </td>
												<td> <?php 
													$qu = " SELECT * FROM inv_invoice WHERE memo_no='".$memo."' ";
													$res = mysqli_query($link, $qu);
													$r=mysqli_fetch_array($res);
													
												echo  $r['name']; ?> </td>
												<td> <?php echo $total_taka; ?> </td>

											</tr>
										<?php
										}
										?>
										<tr class="totalcell">
													<td colspan="3"> Total </td>
													<td> <?php echo $total_takat; ?> </td>
												</tr>
											</table>
							<?php } ?>	
								
								
							</div>
							<div class="salestfooter">
								<div class="row fix">
									<div class="col-md-12">
										<form action="print.php" method="post" >
											<input type="hidden" name="print" id="print" />
											<input type="hidden" name="tabletitle" value="bKash Collections" />
											<button type="submit" class="pbtn">Print</button>
										</form>
									</div>
								</div>
							</div>
						</div>

					</div>

			    </div>

			</div>
	</div>
	<script type="text/javascript">
		$(document).ready(function() {
			var pval = document.getElementById("daily_due").innerHTML;
			document.getElementById("print").value = pval;
		});
	</script>
	
	<script>
		$(document).ready(function() {
				$('#duc_date').Zebra_DatePicker({
					container: $('#ttt')
				});
				$('.Zebra_DatePicker').attr('style', '');
				$('.Zebra_DatePicker_Icon').attr('style', 'top:0px;right:0px;');
			 });
	 </script>
	  <script type="text/javascript">
	$(document).ready(function(){
		$(".Zebra_DatePicker_Icon").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
		$("#duc_date").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
	});		

</script>
	 
	 
	 

		<script type="text/javascript"> <!-- Daily Sales Views -->
		$(document).ready(function(){
			$("#duc_submit").click(function(){
				var duc_date = $('#duc_date').val();
				var duc_product = $('#duc_product').val();
				
				if( duc_date=='' || duc_product=='' ){
					alert("Something Went Wrong!");
				}else{
					$.ajax({
						url:'inc/dailyduc.php',
						method:'POST',
						data:{duc_date:duc_date, duc_product:duc_product},
						success:function(data){
							 $("#daily_due").html(data);
						}
					});
				}
			var pval = document.getElementById("daily_due").innerHTML;
			document.getElementById("print").value = pval;
				
			});
			
			
		});
	</script>
</body>
</html>