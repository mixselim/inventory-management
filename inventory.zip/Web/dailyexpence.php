<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;"><?php echo $pro; ?></h3>
							<header class="tableheader">
								<div class="row fix">
									<div class="col-md-6 fix">
										<div class="dailysales">
										<p>
											Daily Expense
										</p>
										</div>
									</div>
									<div class="col-md-6 fix">
										<div class="sdate">
											<form action="">
												<input type="date" name="viewsdate" id="exvdate" placeholder="Date: yyyy-mm-dd" />
											<input type="button" name="viewssubmit" id="exvsubmit" value="View"/>
											</form>
										</div>
										<div id="expenseshow"></div>
									</div>
									
								</div>
							</header>
							<div class="salestable" id="exvtable" >
								<!-- Expense Table -->
								
							<?php
								$today = date("Y-m-d");
	
								if( $today!="" ){

									$query = "SELECT * FROM inv_expense WHERE exdate='".$today."' ";
									?>
										<table>
											<div class="tablef">
												<tr class="sp">
													<th>Name</th>
													<th>Descriptions</th>
													<th>Taka</th>
												</tr>
											</div>

									<?php
									$result = mysqli_query($link, $query);
									$taka=0.0;
									$total_taka = 0.0;
									while( $row=mysqli_fetch_array($result) ){
										$taka = $row['extaka'];
										$total_taka = $total_taka+$taka;
									?>
										<tr>
											<td> <?php echo $row['name']; ?> </td>
											<td> <?php echo $row['description']; ?> </td>
											<td> <?php echo $taka; ?> </td>
										</tr>
									<?php
									}
									?>
									<tr class="totalcell">
												<td colspan="2"> Total </td>
												<td> <?php echo $total_taka; ?> </td>
											</tr>
										</table>
							<?php } ?>	
							</div>
							<div class="salestfooter">
								<div class="row fix">
									<div class="col-md-12">
										<form action="print.php" method="post" >
											<input type="hidden" name="print" id="print" />
											<input type="hidden" name="tabletitle" value="Daily Expense" />
											<button type="submit" class="pbtn">Print</button>
										</form>
									</div>
								</div>
							</div>
						</div>

					</div>

			    </div>

			</div>
	</div>
	<script>
		$(document).ready(function() {
				$('#exvdate').Zebra_DatePicker({
					container: $('#expenseshow')
				});
				$('.Zebra_DatePicker').attr('style', '');
				$('.Zebra_DatePicker_Icon').attr('style', 'top:0px;right:0px;');
			 });
	 </script>
	  <script type="text/javascript">
	$(document).ready(function(){
		$(".Zebra_DatePicker_Icon").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
		$("#exvdate").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
	});		

</script>


	
		<script type="text/javascript"> 	<!-- Daily Sales Views -->
			$(document).ready(function(){
				$("#exvsubmit").click(function(){
					var exvdate = $('#exvdate').val();
					
					if( exvdate=='' ){
						alert("Something Went Wrong!");
					}else{
						$.ajax({
							url:'inc/expenseview.php',
							method:'POST',
							data:{exvdate:exvdate},
							success:function(data){
								 $("#exvtable").html(data);
							}
						});
					}
					var pval = document.getElementById("exvtable").innerHTML;
					document.getElementById("print").value = pval;
				});
			});
		</script>
		
	<script type="text/javascript">
		$(document).ready(function() {
			var pval = document.getElementById("exvtable").innerHTML;
			document.getElementById("print").value = pval;
		});
	</script>
</body>
</html>