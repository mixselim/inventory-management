<?php
	include_once("header.php");
	$pro = "";
	if(!empty($_GET['tag'])){
		$pro = $_GET['tag'];
	}
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;"><?php echo $pro; ?></h3>
							<header class="tableheader">
								<div class="row fix">
									<div class="col-md-6 fix">
										<div class="dailysales">
										<p>
											Art Farm List
										</p>
										</div>
									</div>
									<div class="col-md-6 fix">
										<div class="sdate">
											<form>
												<input type="date" name="atr_id" id="atr_id" placeholder="ID/Memo" />
												<input type="hidden" name="atr_product" value="<?php echo $pro; ?>" />
												<input type="button" name="viewssubmit" value="View" id="atr_submit" />
												
											</form>
										</div>
									</div>
									
								</div>
							</header>
							<div class="salestable" id="art_table"  >
							
								<!-- Art Firm List Table -->
								
							</div>
							<div class="salestfooter">
								<div class="row fix">
									<div class="col-md-12">
										<button class="pbtn">Print</button>
									</div>
								</div>
							</div>
						</div>

					</div>

			    </div>

			</div>
	</div>
	<script type="text/javascript"> 	<!-- Daily Sales Views -->
		$(document).ready(function(){
			$("#atr_submit").click(function(){
				var atr_id = $('#atr_id').val();
				
				if( atr_id=='' ){
					alert("Something Went Wrong!");
				}else{
					$.ajax({
						url:'inc/viewartfirm.php',
						method:'POST',
						data:{ atr_id:atr_id },
						success:function(data){
							 $("#art_table").html(data);
						}
					});
				}
			});
		});
	</script>
</body>
</html>