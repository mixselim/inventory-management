<?php
include_once('connection/connect.php');
include_once('functions.php'); 
if(!islogin()){
		header('location:login.php');
	}	
	$pro = "";
	if( !empty($_GET['tag']) ){
		$pro = $_GET['tag'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Index Page</title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/default.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	
	<script src="js/zebra_datepicker.js"></script>
	
	<script> <!-- Header Pop Up Page -->
	
	$(document).ready(function(){
		$(".icon1").click(function(){
			$(".menu-pop").css("display", "none");
			$(".user-pop").toggle();
		});
	});
	</script>
	
	<script> <!-- Header Pop Up Page 2 -->
	$(document).ready(function(){
		$(".icon3").click(function(){
			$(".user-pop").css("display", "none");
			$(".menu-pop").toggle();
			
		});
	});
	</script>
	
	<script> <!-- Art Farm -->
	$(document).ready(function(){
		$(".delart").click(function(){
			$(".delform").toggle();
		});
	});
	</script>
	
	<script> <!-- del Invoice -->
	$(document).ready(function(){
		$("#del_inbutton").click(function(){
			$("#del_invoice").toggle();
		});
	});
	</script>
</head>
<body>

	<div id="wrapper">	

			<header>
				<div class="col-md-12 header">
				<?php 
					$mql = "SELECT * FROM inv_setings";
					$res = mysqli_query($link, $mql);
					while( $row = mysqli_fetch_array($res) ){
						$h_ti = $row['header_title'];
						$h_ad = $row['header_adress'];
					}
				
				?>
					<div class="col-md-10">
						<h3><?php echo $h_ti; ?></h3>
						<h5><?php echo $h_ad; ?></h5>
					</div>
					<div class="col-md-2">
						<span class="icon3">
							<a href="#">
								<img src="images/menu.png" alt="" width="30px" height="30px"/>
							</a>
							<div class="menu-pop">
								<ul>
									<li><a href="mainmenu.php?tag=<?php echo $pro; ?>"  style="color:gray" > Main Menu </a></li>
									<li><a href="index.php?tag=<?php echo $pro; ?>"> Products List </a></li>
									<li><a href="newinvoice.php?tag=<?php echo $pro; ?>"  style="color:gray"> Invoice </a></li>
									<li><a href="atrfarm.php?tag=<?php echo $pro; ?>" > Art Firm </a></li>
									<li><a href="artfarmlist.php?tag=<?php echo $pro; ?>" > Art Firm List </a></li>
									<li><a href="dailysales.php?tag=<?php echo $pro; ?>" style="color:gray" > Daily Sales </a></li>
									<li><a href="monthlysales.php?tag=<?php echo $pro; ?>"  style="color:gray"> Monthly Sales </a></li>
									<li><a href="yearlysales.php?tag=<?php echo $pro; ?>"  style="color:gray"> Yearly Sales </a></li>
								</ul>
							</div>
						</span>
						<span class="icon2">
							<a href="#">
								<img src="images/icon2.png" alt="" width="30px" height="30px"/>
							</a>

						</span>
						<span class="icon1">
							<a href="#">
								<img src="images/icon1.png" alt="" width="30px" height="30px"/>
							</a>
							<div class="user-pop">
								<div><span>Hi! </span><?php echo $_SESSION['user']; ?></div>
								<div>
									<?php if($_SESSION['type']=='1'){
										?>
										<a href="users.php"><button class="userbtn" >Users</button></a>
										
										<?php
									} ?>
									<a href="logout.php"><button class="logoutbtn" >Logout</button></a>
								</div>
								
							</div>
						</span>
						
					</div>
					
				</div>
			</header>