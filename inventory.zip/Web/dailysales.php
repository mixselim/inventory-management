<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;" ><?php echo $pro; ?></h3>
							<header class="tableheader">
								<div class="row fix">
									<div class="col-md-8 fix">
										<div class="dailysales">
										<p>
											View Daily Sales
										</p>
										</div>
									</div>
									<div class="col-md-4 fix">
										<div class="sdate">
											<form>
												<input type="date" name="viewsdate" placeholder="yyyy-mm-dd" id="vs_date" />
												<input type="hidden" id="vs_product" value="<?php echo $pro; ?>" />
												<input type="button" name="viewssubmit" id="vs_submit" value="View"/>
											</form>
										</div>
										<div id="vsshow"></div>
									</div>
									
								</div>
							</header>
							<div class="salestable" id="sales">
								<!-- Sales Table Goes here.... -->
								
							<?php
								$taday = date("Y-m-d");
								
								if( $taday!='' ){

									$query = "SELECT * FROM inv_invoice WHERE date='".$taday."' AND products='".$pro."' ";
									?>
										<table>
											<div class="tablef">
												<tr class="sp">
													<th>ID No</th>
													<th>Memo No</th>
													<th>Name</th>
													<th>Total</th>
													<th>Advance</th>
													<th>Due</th>
													<th>Bkash</th>
												</tr>
											</div>

									<?php
									$result = mysqli_query($link, $query);
									$t_total=0.0;
									$t_tadvance=0.0;
									$t_due=0.0;
									while( $row=mysqli_fetch_array($result) ){
										$total = $row['total_taka'];
										$advance = $row['advance'];
										$due = $row['due'];
										$t_total = $t_total+$total;
										$t_tadvance = $t_tadvance+$advance;
										$t_due = $t_due+$due;
									?>
										<tr>
												<td> <?php echo $row['id_no']; ?> </td>
												<td> <?php echo $row['memo_no']; ?> </td>
												<td> <?php echo $row['name']; ?> </td>
												<td> <?php echo  $total; ?> </td>
												<td> <?php echo $advance; ?> </td>
												<td> <?php echo $due; ?> </td>
												<td> <?php echo $row['bkash']; ?> </td>

											</tr>
									<?php
									}
									?>
									<tr class="totalcell">
												<td colspan="3"> Total </td>
												<td> <?php echo $t_total; ?> </td>
												<td> <?php echo $t_tadvance; ?> </td>
												<td> <?php echo $t_due; ?> </td>
												<td>  </td>
											</tr>
										</table>
							<?php } ?>	
							</div>
							<div class="salestfooter">
								<div class="row fix">
									<div class="col-md-12">
										<form action="print.php" method="post" >
											<input type="hidden" name="print" id="print" />
											<input type="hidden" name="tabletitle" value="Daily Sales" />
											<button type="submit" class="pbtn">Print</button>
										</form>
									</div>
								</div>
							</div>
						</div>

					</div>

			    </div>

			</div>
	</div>
	<script>
		$(document).ready(function() {
				$('#vs_date').Zebra_DatePicker({
					container: $('#vsshow')
				});
				$('.Zebra_DatePicker').attr('style', '');
				$('.Zebra_DatePicker_Icon').attr('style', 'top:0px;right:0px;');
			 });
	 </script>
	  <script type="text/javascript">
	$(document).ready(function(){
		$(".Zebra_DatePicker_Icon").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
		$("#vs_date").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
	});		

</script>
	
	
	
	
	
	<script type="text/javascript"> <!-- Daily Sales Views -->
		$(document).ready(function(){
			$("#vs_submit").click(function(){
				var vs_product = $('#vs_product').val();
				var vs_date = $('#vs_date').val();
				
				if( vs_product=='' || vs_date=='' ){
					alert("Something Went Wrong!");
				}else{
					$.ajax({
						url:'inc/dailysalesview.php',
						method:'POST',
						data:{vs_product:vs_product, vs_date:vs_date},
						success:function(data){
							 $(".salestable").html(data);
						}
					});
				}
				var pval = document.getElementById("sales").innerHTML;
				document.getElementById("print").value = pval;
			});
		});
	</script>
	
	<script type="text/javascript">
		$(document).ready(function() {
			var pval = document.getElementById("sales").innerHTML;
			document.getElementById("print").value = pval;
		});
	</script>
</body>
</html>