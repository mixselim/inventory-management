<?php
	include_once('../connection/connect.php');	
	
	if( true ){
	
		$user_name = $_POST['user_name'];
		$newpass = $_POST['newpass'];
		$newpass = md5($newpass);
		
		$mql = "UPDATE inv_users SET password='".$newpass."' WHERE username='".$user_name."' ";
		if( mysqli_query($link, $mql) ){
			echo "UPDATED";
		}else{
			"Wrong try again.";
		}
	}
	
?>