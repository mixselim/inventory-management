<?php
	include_once('../connection/connect.php');	

	$oldpass = $_POST['oldpass'];
	$user_name = $_POST['user_name'];
	$oldpass = md5($oldpass);
	$mql = "SELECT * FROM inv_users WHERE username='".$user_name."' ";
	$res = mysqli_query($link, $mql);
	$row = mysqli_fetch_array($res);
	if( strcmp($row['password'], $oldpass) == 0 ){
		echo 'Matched.';
	}else{
		echo 'Mismatched.';
	}
	
?>