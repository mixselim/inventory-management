<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;" ><?php echo $pro; ?></h3>
							<header class="tableheader">
								<div class="row fix">
									<div class="col-md-6 fix">
										<div class="dailysales">
											<p>
												Yearly Sales
											</p>
										</div>
									</div>
									<div class="col-md-6 fix">
										<div class="sdate">
											<form>
											<?php 
												$year = date('Y');
												
											
											?>
												
											<select name="ms_year" id="ms_year">
													<option value="2015" <?php if($year==2015) echo 'selected' ?> > 2015 </option>
													<option value="2016" <?php if($year==2016) echo 'selected' ?>  > 2016 </option>
													<option value="2017" <?php if($year==2017) echo 'selected' ?>  > 2017 </option>
													<option value="2018" <?php if($year==2018) echo 'selected' ?>  > 2018 </option>
													<option value="2019" <?php if($year==2019) echo 'selected' ?>  > 2019 </option>
													<option value="2020" <?php if($year==2020) echo 'selected' ?> > 2020 </option>
													<option value="2021" <?php if($year==2021) echo 'selected' ?>  > 2021 </option>
													<option value="2022" <?php if($year==2022) echo 'selected' ?>  > 2022 </option>
													<option value="2023" <?php if($year==2023) echo 'selected' ?>  > 2023 </option>
													<option value="2024" <?php if($year==2024) echo 'selected' ?>  > 2024 </option>
													<option value="2025" <?php if($year==2025) echo 'selected' ?>  > 2025 </option>
													<option value="2026" <?php if($year==2026) echo 'selected' ?>  > 2026 </option>
												</select>
												<input type="hidden" name="ms_product" id="ms_product" value="<?php echo $pro; ?>" />
												<input type="button" name="ms_submit" id="ms_submit" value="View" />
												
											</form>
										</div>
									</div>
								</div>
							</header>
							<div class="salestable" id="ms_table" >
								<!-- Monthly Sales -->
								<?php	
											
											$ms_year = date('Y');
											$ms_product =  $pro;
											
											$query = "SELECT * FROM inv_invoice WHERE Year(date) = '$ms_year' LIMIT 30 ";
											
											$result = mysqli_query($link, $query);
											
											$sales = array(); 
											$advance = array();
											$due = array();
											
											for($i=0;$i<=31;$i++){
												$sales[$i] = 0.0; 
												$advance[$i] = 0.0;
												$due[$i] = 0.0;
											}
											
											while( $row=mysqli_fetch_array($result) ){

												$string = $row['date'];
												$timestamp = strtotime($string);
												$d = date("d", $timestamp);
												$day = intval($d);
												
												$sales[$day] = $sales[$day] + $row['total_taka']; 
												$advance[$day] = $advance[$day] + $row['advance'];
												$due[$day] = $due[$day] + $row['due'];
											}
											/* Due Collections */
											$query = "SELECT * FROM inv_ducollections WHERE Year(indate) = '$ms_year' ";
											
											$result = mysqli_query($link, $query);
											
											$duec = array(); 
											for($i=0;$i<=31;$i++){
												$duec[$i] = 0.0;
											}
											
											while( $row=mysqli_fetch_array($result) ){

												$string = $row['indate'];
												$timestamp = strtotime($string);
												$day = date("d", $timestamp);
												$day = intval($day);
												$duec[$day] = $duec[$day] + $row['dutaka'];
											}
											/* Daily Expense */
											$query = "SELECT * FROM inv_expense WHERE Year(exdate) = '$ms_year' ";
											
											$result = mysqli_query($link, $query);
											
											$extaka = array();
											
											for($i=0;$i<=31;$i++){
												$extaka[$i] = 0.0; 
											}
											
											while( $row=mysqli_fetch_array($result) ){

												$string = $row['exdate'];
												$timestamp = strtotime($string);
												$d = date("d", $timestamp);
												$day = intval($d);
												$extaka[$day] = $extaka[$day] + $row['extaka'];
											}
											
											/* bKash Collections */
											$query = "SELECT * FROM inv_bkash WHERE Year(bkdate) = '$ms_year' ";
											
											$result = mysqli_query($link, $query);
											
											$bktaka = array(); 
											
											for($i=0;$i<=31;$i++){
												$bktaka[$i] = 0.0;
											}
											
											while( $row=mysqli_fetch_array($result) ){

												$string = $row['bkdate'];
												$timestamp = strtotime($string);
												$d = date("d", $timestamp);
												$day = intval($d);
												$bktaka[$day] = $bktaka[$day] + $row['bkdate'];
											}
											/* Offset */
											
											$query = "SELECT * FROM inv_invoice WHERE Year(date) = '$ms_year' and products='offset' ";
											
											$result = mysqli_query($link, $query);
											
											$offset = array(); 
											
											for($i=0;$i<=31;$i++){
												$offset[$i] = 0.0;
											}
											
											while( $row=mysqli_fetch_array($result) ){

												$string = $row['date'];
												$timestamp = strtotime($string);
												$day = date("d", $timestamp);
												
												$offset[$day] = $offset[$day] + $row['total_taka'];
											}
											?>
												<table>
													<div class="tablef">
														<tr class="sp">
															<th>Date</th>
															<th>Sales</th>
															<th>Cash</th>
															<th>Due</th>
															<th>Due cash</th>
															<th>Total cash</th>
															<th>Expense</th>
															<th>Balance</th>
															<th>Offset</th>
															<th>Total Balance</th>
															<th>Last Day Balance</th>
														</tr>
													</div>

											<?php
											$Cash = 0.0;
											$tcash = 0.0;
											$balance = 0.0;
											$tbalance = 0.0;
											$lastdaybalance = 0.0;
											
											$t_Sales = 0.0;
											$t_Cash = 0.0;
											$t_Due = 0.0;
											$t_duecash = 0.0;
											$t_tcash = 0.0;
											$t_expense = 0.0;
											$t_balacnce = 0.0;
											$t_offset = 0.0;
											$t_tbalance = 0.0;
											$t_lastdaybalance = 0.0;
											
											for( $i=1;$i<=30;$i++ ){
											
												$tcash = $duec[$i]+$due[$i];
												$balance = $duec[$i]+$due[$i]-$extaka[$i];;
												$tbalance = $duec[$i]+$due[$i]-$extaka[$i]+$offset[$i];
												if($i!=1){
													$lastdaybalance = $lastdaybalance + $duec[$i-1]+$due[$i-1]-$extaka[$i-1]+$offset[$i-1];
												}else{
													
												}
												
												$t_Sales = $t_Sales+$sales[$i];
												$t_Cash = $t_Cash+$advance[$i];
												$t_Due = $t_Due+$due[$i];
												$t_duecash = $t_duecash+$duec[$i];
												$t_tcash = $t_tcash+$tcash;
												$t_expense = $t_expense+$extaka[$i];
												$t_balacnce = $t_balacnce+$balance;
												$t_offset = $t_offset+$offset[$i];;
												$t_tbalance = $t_tbalance+$tbalance;
											?>
												<tr>
													<td> <?php echo $i; ?> </td>
													<td> <?php echo $sales[$i]; ?> </td>
													<td> <?php echo $advance[$i]; ?> </td>
													<td> <?php echo $due[$i]; ?> </td>
													<td> <?php echo $duec[$i]; ?> </td>
													<td> <?php echo $tcash; ?> </td>
													<td> <?php echo $extaka[$i]; ?> </td>
													<td> <?php echo $balance; ?> </td>
													<td> <?php echo $offset[$i]; ?> </td>
													<td> <?php echo $tbalance; ?> </td>
													<td> <?php echo $lastdaybalance; ?> </td>

												</tr>
											<?php
											}
											?>
												<tr>
													<td>Total</td>
													<td><?php echo $t_Sales; ?></td>
													<td><?php echo $t_Cash; ?></td>
													<td><?php echo $t_Due; ?></td>
													<td><?php echo $t_duecash; ?></td>
													<td><?php echo $t_tcash; ?></td>
													<td><?php echo $t_expense; ?></td>
													<td><?php echo $t_balacnce; ?></td>
													<td><?php echo $t_offset; ?></td>
													<td><?php echo $t_tbalance; ?></td>
													<td></td>
												
												</tr>
												</table>	
							</div>
							<div class="salestfooter">
								<div class="row fix">
									<div class="col-md-12">
										<form action="print.php" method="post" >
											<input type="hidden" name="print" id="print" />
											<input type="hidden" name="tabletitle" value="Daily Sales" />
											<button type="submit" class="pbtn">Print</button>
										</form>
									</div>
								</div>
							</div>
						</div>

					</div>

			    </div>

			</div>
	</div>
	
	<script type="text/javascript"> 	<!-- Yearly Sales Views -->
		$(document).ready(function(){
			$("#ms_submit").click(function(){
				var ms_year = $('#ms_year').val();
				var ms_product = $('#ms_product').val();
				
				if( ms_year=='' ){
					alert("Something Went Wrong!");
				}else{
					$.ajax({
						url:'inc/yearlysalesview.php',
						method:'POST',
						data:{ ms_year:ms_year, ms_product:ms_product},
						success:function(data){
							 $("#ms_table").html(data);
						}
					});
				}
				var pval = document.getElementById("ms_table").innerHTML;
				document.getElementById("print").value = pval;
			});
		});
	</script>
	
	<script type="text/javascript"> <!-- Table Print -->
		$(document).ready(function() {
			var pval = document.getElementById("ms_table").innerHTML;
			document.getElementById("print").value = pval;
		});
	</script>
</body>
</html>