<?php
	include_once("header.php");
 ?>
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 btn-cls fix">
							<p>
							<a href="mainmenu.php?tag=digital">
								<button type="button" class="btn btn-primary">Digital</button>
							</a>
							<a href="mainmenu.php?tag=offset">
								<button type="button" class="btn btn-primary">Offset</button>
							</a>
							<a href="mainmenu.php?tag=bag">
								<button type="button" class="btn btn-primary">Bag</button>
							</a>
							<a href="atrfarm.php">
								<button type="button" class="btn btn-primary">Alt Farm</button>
							</a>
							<a href="mainmenu.php?tag=others">
								<button type="button" class="btn btn-primary">Others</button>
							</a>
							</p>

						</div>

					</div>

			    </div>

			</div>


		

	</div>

</body>
</html>