<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3><?php echo $pro; ?></h3>
							<div class="col-md-12 page3_main_body_right fix">
								<h4>VIEW INVOICE</h4>
								<form class="form-horizontal">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Memo No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="vw_memo" placeholder="Memo No">
								    </div>

								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3"></label>
								    <div class="col-sm-9">
								       <input type="button" id="vw_submit" class="btn btn-default" value="VIEW"/>
								    </div>
								  </div>

								 
								</form>


							<form class="form-horizontal">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Date</label>
								    <div class="col-sm-9">
								      <input type="date" class="form-control" id="vw_date" placeholder="Date" readonly />
								    </div>
								  </div>
								  
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="vw_id" placeholder="ID No" readonly />
								    </div>
								  </div>
								  
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="vw_name" placeholder="Name" readonly />
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="vw_taka" class="col-sm-3 control-label">Total Take</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="vw_taka" placeholder="Total Take" readonly />
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Advance</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="vw_advance" placeholder="Advance" readonly />
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Due</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="vw_due" placeholder="Due" readonly />
								    </div>
								  </div>
									<div>
										<input type="hidden" name="vw_product" id="vw_product" value="<?php echo $pro; ?>" />
									</div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Bkash</label>
								    <div class="col-sm-9">
								      <input type="button" style="height:36px" id="vw_byes" value=""  class="btn btn-default" readonly />
								    </div>
								  </div>
	  
								</form>
	
							</div>


						</div>

					</div>

			    </div>

			</div>
	</div>

		<script type="text/javascript"> <!-- VIEW Invoice -->
		$(document).ready(function(){
			$("#vw_submit").click(function(){
				var vw_product = $('#vw_product').val();
				var vw_memo = $('#vw_memo').val();
				
				if( vw_memo=='' ){
					alert('Please enter Memo No');
				}else{
					$.ajax({
						url:'inc/viewinvoicepart.php',
						method:'POST',
						data:{vw_memo:vw_memo, vw_product:vw_product},
						dataType:'json',
						success:function(data){
							$('#vw_date').val(data[0]);
							$('#vw_id').val(data[1]);
							$('#vw_name').val(data[2]);
							$('#vw_taka').val(data[3]);
							$('#vw_advance').val(data[4]);
							$('#vw_due').val(data[5]);
							if(data[6]=='yes'){
								$('#vw_byes').val("Yes");
							}else{
								
								$('#vw_byes').val("No");
							}
							
						}
					});
				}
			});
		});
	</script>
</body>
</html>