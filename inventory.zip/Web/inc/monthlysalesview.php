<?php

include_once('../connection/connect.php');	
	
	
if( !empty($_POST['ms_month']) && !empty($_POST['ms_year']) && !empty($_POST['ms_product']) ){
		
		
		$ms_month = $_POST['ms_month'];
		$ms_year = $_POST['ms_year'];
		$ms_product = $_POST['ms_product'];
		$daycount = 0;
		if( $ms_month==1 || $ms_month==3 || $ms_month==5 || $ms_month==7 || $ms_month==8 || $ms_month==10 || $ms_month==12 ){
			$daycount = 31;
		}else if($ms_month==2){
			$daycount = 28;
			if($ms_year%4==0){
				$daycount = 29;
			}
		}else{
			$daycount = 30;
		}
		$query = "SELECT * FROM inv_invoice WHERE Year(date) = '$ms_year' and Month(date) = '$ms_month' ";
		
		$result = mysqli_query($link, $query);
		
		$sales = array(); 
		$advance = array();
		$due = array();
		
		for($i=0;$i<=31;$i++){
			$sales[$i] = 0.0; 
			$advance[$i] = 0.0;
			$due[$i] = 0.0;
		}
		
		while( $row=mysqli_fetch_array($result) ){

			$string = $row['date'];
			$timestamp = strtotime($string);
			$d = date("d", $timestamp);
			$day = intval($d);
			
			$sales[$day] = $sales[$day] + $row['total_taka']; 
			$advance[$day] = $advance[$day] + $row['advance'];
			$due[$day] = $due[$day] + $row['due'];
		}
		/* Due Collections */
		$query = "SELECT * FROM inv_ducollections WHERE Year(indate) = '$ms_year' and Month(indate) = '$ms_month' ";
		
		$result = mysqli_query($link, $query);
		
		$duec = array(); 
		for($i=0;$i<=31;$i++){
			$duec[$i] = 0.0;
		}
		
		while( $row=mysqli_fetch_array($result) ){

			$string = $row['indate'];
			$timestamp = strtotime($string);
			$day = date("d", $timestamp);
			$day = intval($day);
			$duec[$day] = $duec[$day] + $row['dutaka'];
		}
		/* Daily Expense */
		$query = "SELECT * FROM inv_expense WHERE Year(exdate) = '$ms_year' and Month(exdate) = '$ms_month' ";
		
		$result = mysqli_query($link, $query);
		
		$extaka = array();
		
		for($i=0;$i<=31;$i++){
			$extaka[$i] = 0.0; 
		}
		
		while( $row=mysqli_fetch_array($result) ){

			$string = $row['exdate'];
			$timestamp = strtotime($string);
			$d = date("d", $timestamp);
			$day = intval($d);
			$extaka[$day] = $extaka[$day] + $row['extaka'];
		}
		
		/* bKash Collections */
		$query = "SELECT * FROM inv_bkash WHERE Year(bkdate) = '$ms_year' and Month(bkdate) = '$ms_month' ";
		
		$result = mysqli_query($link, $query);
		
		$bktaka = array(); 
		
		for($i=0;$i<=31;$i++){
			$bktaka[$i] = 0.0;
		}
		
		while( $row=mysqli_fetch_array($result) ){

			$string = $row['bkdate'];
			$timestamp = strtotime($string);
			$d = date("d", $timestamp);
			$day = intval($d);
			$bktaka[$day] = $bktaka[$day] + $row['bkdate'];
		}
		/* Offset */
		
		$query = "SELECT * FROM inv_invoice WHERE Year(date) = '$ms_year' and Month(date) = '$ms_month' and products='offset' ";
		
		$result = mysqli_query($link, $query);
		
		$offset = array(); 
		
		for($i=0;$i<=31;$i++){
			$offset[$i] = 0.0;
		}
		
		while( $row=mysqli_fetch_array($result) ){

			$string = $row['date'];
			$timestamp = strtotime($string);
			$day = date("d", $timestamp);
			
			$offset[$day] = $offset[$day] + $row['total_taka'];
		}
		?>
			<table>
				<div class="tablef">
					<tr class="sp">
						<th>Date</th>
						<th>Sales</th>
						<th>Cash</th>
						<th>Due</th>
						<th>Due cash</th>
						<th>Total cash</th>
						<th>Expense</th>
						<th>Balance</th>
						<th>Offset</th>
						<th>Total Balance</th>
						<th>Last Day Balance</th>
					</tr>
				</div>

		<?php
		$Cash = 0.0;
		$tcash = 0.0;
		$balance = 0.0;
		$tbalance = 0.0;
		$lastdaybalance = 0.0;
		
		$t_Sales = 0.0;
		$t_Cash = 0.0;
		$t_Due = 0.0;
		$t_duecash = 0.0;
		$t_tcash = 0.0;
		$t_expense = 0.0;
		$t_balacnce = 0.0;
		$t_offset = 0.0;
		$t_tbalance = 0.0;
		$t_lastdaybalance = 0.0;
		
		for( $i=1;$i<=$daycount;$i++ ){
		
			$tcash = $duec[$i]+$due[$i];
			$balance = $duec[$i]+$due[$i]-$extaka[$i];;
			$tbalance = $duec[$i]+$due[$i]-$extaka[$i]+$offset[$i];
			if($i!=1){
				$lastdaybalance = $duec[$i-1]+$due[$i-1]-$extaka[$i-1]+$offset[$i-1];
			}else{
				
			}
			
			$t_Sales = $t_Sales+$sales[$i];
			$t_Cash = $t_Cash+$tcash;
			$t_Due = $t_Due+$due[$i];
			$t_duecash = $t_duecash+$duec[$i];
			$t_tcash = $t_tcash+$tcash;
			$t_expense = $t_expense+$extaka[$i];
			$t_balacnce = $t_balacnce+$balance;
			$t_offset = $t_offset+$offset[$i];;
			$t_tbalance = $t_tbalance+$tbalance;
			$t_lastdaybalance = $t_lastdaybalance+$lastdaybalance;
		?>
			<tr>
				<td> <?php echo $i; ?> </td>
				<td> <?php echo $sales[$i]; ?> </td>
				<td> <?php echo $advance[$i]; ?> </td>
				<td> <?php echo $due[$i]; ?> </td>
				<td> <?php echo $duec[$i]; ?> </td>
				<td> <?php echo $tcash; ?> </td>
				<td> <?php echo $extaka[$i]; ?> </td>
				<td> <?php echo $balance; ?> </td>
				<td> <?php echo $offset[$i]; ?> </td>
				<td> <?php echo $tbalance; ?> </td>
				<td> <?php echo $lastdaybalance; ?> </td>

			</tr>
		<?php
		}
		?>
			<tr>
				<td>Total</td>
				<td><?php echo $t_Sales; ?></td>
				<td><?php echo $t_Cash; ?></td>
				<td><?php echo $t_Due; ?></td>
				<td><?php echo $t_duecash; ?></td>
				<td><?php echo $t_tcash; ?></td>
				<td><?php echo $t_expense; ?></td>
				<td><?php echo $t_balacnce; ?></td>
				<td><?php echo $t_offset; ?></td>
				<td><?php echo $t_tbalance; ?></td>
				<td><?php echo $t_lastdaybalance; ?></td>
			
			</tr>
			</table>
	<?php } ?>	