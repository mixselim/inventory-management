<?php
	include_once('../connection/connect.php');	
	
	if( !empty($_POST['vs_product']) && !empty($_POST['vs_date']) ){
	
		$vs_product = $_POST['vs_product'];
		$vs_date = $_POST['vs_date'];

		$query = "SELECT * FROM inv_invoice WHERE date='".$vs_date."' AND products='".$vs_product."' ";
		?>
			<table>
				<div class="tablef">
					<tr class="sp">
						<th>ID No</th>
						<th>Memo No</th>
						<th>Name</th>
						<th>Total</th>
						<th>Advance</th>
						<th>Due</th>
						<th>Bkash</th>
					</tr>
				</div>

		<?php
		$result = mysqli_query($link, $query);
		$t_total=0.0;
		$t_tadvance=0.0;
		$t_due=0.0;
		while( $row=mysqli_fetch_array($result) ){
			$total = $row['total_taka'];
			$advance = $row['advance'];
			$due = $row['due'];
			$t_total = $t_total+$total;
			$t_tadvance = $t_tadvance+$advance;
			$t_due = $t_due+$due;
		?>
			<tr>
					<td> <?php echo $row['id_no']; ?> </td>
					<td> <?php echo $row['memo_no']; ?> </td>
					<td> <?php echo $row['name']; ?> </td>
					<td> <?php echo  $total; ?> </td>
					<td> <?php echo $advance; ?> </td>
					<td> <?php echo $due; ?> </td>
					<td> <?php echo $row['bkash']; ?> </td>

				</tr>
		<?php
		}
		?>
		<tr class="totalcell">
					<td colspan="3"> Total </td>
					<td> <?php echo $t_total; ?> </td>
					<td> <?php echo $t_tadvance; ?> </td>
					<td> <?php echo $t_due; ?> </td>
					<td>  </td>
				</tr>
			</table>
	<?php } ?>	