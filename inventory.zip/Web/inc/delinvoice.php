<?php
	include_once('../connection/connect.php');	
	
	if( !empty($_POST['del_id']) && !empty($_POST['del_memo']) && !empty($_POST['del_product']) ){
		$del_id = $_POST['del_id'];
		$del_memo = $_POST['del_memo'];
		$del_product = $_POST['del_product'];
		
		$mql = "DELETE FROM inv_invoice WHERE products='".$del_product."' AND id_no='".$del_id."' OR memo_no='".$del_memo."' ";
		if( mysqli_query($link, $mql) ){
			echo "DELETED";
		}else{
			echo "SomeThing Went Wrong";
		}
	}
	
?>