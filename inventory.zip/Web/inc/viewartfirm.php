<?php
	include_once('../connection/connect.php');	
	
	
if( !empty( $_POST['atr_id']) ){
	
		$atr_id = $_POST['atr_id'];
		$query = "SELECT * FROM inv_artfirm WHERE id_no='".$atr_id."' OR propitor_name='".$atr_id."' OR office_name='".$atr_id."' ";
		?>
			<table>
				<div class="tablef">
					<tr class="sp">
						<th>ID No</th>
						<th>Office Name</th>
						<th>Propitor Name</th>
						<th>Address</th>
						<th>Telephone</th>
						<th>Mobile</th>
						<th>Email</th>
						<th></th>
						<th></th>
					</tr>
				</div>

		<?php
		$result = mysqli_query($link, $query);
		while( $row=mysqli_fetch_array($result) ){

		?>
			<tr>
				<td>  <?php echo $row['id_no']; ?>  </td>
				<td>  <?php echo $row['office_name']; ?>  </td>
				<td>  <?php echo $row['propitor_name']; ?>  </td>
				<td>  <?php echo $row['address']; ?>  </td>
				<td>  <?php echo $row['telephone']; ?>  </td>
				<td>  <?php echo $row['mobile']; ?>  </td>
				<td>  <?php echo $row['email']; ?>  </td>
				<td class="noborder"><a href="editartfarm.php?st=modi&id=<?php echo $row['id_no']; ?> " >Edit</a></td>
				<td class="noborder"><a href="">Delete</a></td>
			</tr>
		<?php
		}
		?>
		</table>
	<?php } ?>	