<?php
	include_once('../connection/connect.php');	
	
	
if( !empty($_POST['duc_date']) && !empty($_POST['duc_product']) ){
	
		$duc_date = $_POST['duc_date'];
		$duc_product = $_POST['duc_product'];

		$query = "SELECT * FROM inv_ducollections WHERE indate='".$duc_date."' AND products='".$duc_product."' ";
		?>
			<table>
				<div class="tablef">
				<tr class="sp">
					<th>ID No</th>
					<th>Memo No</th>
					<th>Name</th>
					<th>Taka</th>
				</tr>
				</div>

		<?php
		$result = mysqli_query($link, $query);
		$total_taka=0.0;
		$total_takat = 0.0;
		while( $row=mysqli_fetch_array($result) ){
			$total_taka = $row['dutaka'];
			$total_takat = $total_takat+$total_taka;
			$memo = $row['dumemo'];
		?>
			<tr>
				<td> <?php echo $row['duid']; ?> </td>
				<td> <?php echo $memo ?> </td>
				<td> <?php 
					$qu = " SELECT * FROM inv_invoice WHERE memo_no='".$memo."' ";
					$res = mysqli_query($link, $qu);
					$r=mysqli_fetch_array($res);
					
				echo  $r['name']; ?> </td>
				<td> <?php echo $total_taka; ?> </td>

			</tr>
		<?php
		}
		?>
		<tr class="totalcell">
					<td colspan="3"> Total </td>
					<td> <?php echo $total_takat; ?> </td>
				</tr>
			</table>
	<?php } ?>	