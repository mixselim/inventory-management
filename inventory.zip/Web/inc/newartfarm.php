<?php
	include_once('../connection/connect.php');	
	
	if( true ){
	
		$at_id = $_POST['at_id'];
		$at_office = $_POST['at_office'];
		$at_propitor = $_POST['at_propitor'];
		$at_address = $_POST['at_address'];
		$at_telephone = $_POST['at_telephone'];
		$at_mobile = $_POST['at_mobile'];
		$at_email = $_POST['at_email'];
		
		$mql = "INSERT INTO inv_artfirm(id, id_no, office_name, propitor_name, address, telephone, mobile, email) values('', '".$at_id."', '".$at_office."', '".$at_propitor."', '".$at_address."', '".$at_telephone."', '".$at_mobile."', '".$at_email."' )";
		if( mysqli_query($link, $mql) ){
			echo "Saved";
		}
	}
	
?>