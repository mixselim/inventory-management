<?php
	include_once('../connection/connect.php');	
	
	if( true ){

		$inproduct = $_POST['inproduct'];
		$inidno = $_POST['inidno'];
		$indate = $_POST['indate'];
		$inname = $_POST['inname'];
		$inmemono = $_POST['inmemono'];
		$intotaltaka = $_POST['intotaltaka'];
		$inadvance = $_POST['inadvance'];
		$indue = $_POST['indue'];
		$inbkash = $_POST['inbkash'];
		
		$time = strtotime($indate);
		$newformat = date('Y-m-d',$time);
		
		$mql = "INSERT INTO inv_invoice(id, products, id_no, date, name, memo_no, total_taka, advance, due, bkash) values('', '".$inproduct."', '".$inidno."', '".$newformat."', '".$inname."', '".$inmemono."', '".$intotaltaka."', '".$inadvance."', '".$indue."', '".$inbkash."' )";
		if( mysqli_query($link, $mql) ){
			echo "Saved";
		}
	}
	
?>