<?php
	include_once('../connection/connect.php');	
	
	if( true ){
		$inproduct = $_POST['inproduct'];
		$duid = $_POST['duid'];
		$indate = $_POST['indate'];
		$dumemo = $_POST['dumemo'];
		$dutaka = $_POST['dutaka'];
		
		$mql = "INSERT INTO inv_ducollections(id, products, duid, indate, dumemo, dutaka) values('', '".$inproduct."', '".$duid."', '".$indate."', '".$dumemo."', '".$dutaka."' )";
		if( mysqli_query($link, $mql) ){
			echo "Saved";
		}else{
			echo "All fields are required.";
		}
	}
	
?>