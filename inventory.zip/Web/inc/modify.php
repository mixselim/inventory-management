<?php
	include_once('../connection/connect.php');	
	
	if( true ){
	
		$modi_smemo = $_POST['modi_smemo'];
		$modi_product = $_POST['modi_product'];
		$modi_id = $_POST['modi_id'];
		$modi_name = $_POST['modi_name'];
		$modi_taka = $_POST['modi_taka'];
		$modi_advance = $_POST['modi_advance'];
		$modi_due = $_POST['modi_due'];
		$mql = "UPDATE inv_invoice SET id_no='".$modi_id."', name='".$modi_name."', total_taka='".$modi_taka."', advance='".$modi_advance."', due='".$modi_due."' WHERE products='".$modi_product."' AND memo_no='".$modi_smemo."' ";
		if( mysqli_query($link, $mql) ){
			echo "UPDATED";
		}
	}
	
?>