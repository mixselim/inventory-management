<?php
	include_once('../connection/connect.php');	
	
	if( true ){
		$exname = $_POST['exname'];
		$indate = $_POST['indate'];
		$exdes = $_POST['exdes'];
		$extaka = $_POST['extaka'];
		
		$mql = "INSERT INTO inv_expense(id, name, exdate,description, extaka) values('', '".$exname."', '".$indate."', '".$exdes."', '".$extaka."' )";
		if( mysqli_query($link, $mql) ){
			echo "Saved";
		}else{
			echo "All fields are required.";
		}
	}
	
?>