<?php
include_once('../connection/connect.php');	
	if( true ){
		$inproduct = $_POST['inproduct'];
		$bkid = $_POST['bkid'];
		$indate = $_POST['indate'];
		$bkmemo = $_POST['bkmemo'];
		$bktaka = $_POST['bktaka'];
		$bkmobile = $_POST['bkmobile'];
		
		$mql = "INSERT INTO inv_bkash(id, products, bkid, bkdate, bkmemo, bktaka, bkmobile) values('', '".$inproduct."', '".$bkid."', '".$indate."', '".$bkmemo."', '".$bktaka."', '".$bkmobile."' )";
		if( mysqli_query($link, $mql) ){
			echo "Saved";
		}else{
			echo "All fields are required.";
		}
	}
	
?>