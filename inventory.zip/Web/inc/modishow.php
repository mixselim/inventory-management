<?php
	include_once('../connection/connect.php');	
	
	$memo_number = $_POST['modi_smemo'];
	$query = "SELECT * FROM inv_invoice WHERE memo_no ='$memo_number' ";
	$result = mysqli_query($link, $query);
	$row=mysqli_fetch_array($result);
	$arr = array();
	$arr[0] = $row['id_no'];
	$arr[1] = $row['name'];
	$arr[2] = $row['total_taka'];
	$arr[3] = $row['advance'];
	$arr[4] = $row['due'];
	
	echo json_encode($arr);
	exit();
	
?>