<?php
	include_once('../connection/connect.php');	
	
	
if( !empty($_POST['exvdate']) ){
	
		$exvdate = $_POST['exvdate'];

		$query = "SELECT * FROM inv_expense WHERE exdate='".$exvdate."' ";
		?>
			<table>
				<div class="tablef">
					<tr class="sp">
						<th>Name</th>
						<th>Descriptions</th>
						<th>Taka</th>
					</tr>
				</div>

		<?php
		$result = mysqli_query($link, $query);
		$taka=0.0;
		$total_taka = 0.0;
		while( $row=mysqli_fetch_array($result) ){
			$taka = $row['extaka'];
			$total_taka = $total_taka+$taka;
		?>
			<tr>
				<td> <?php echo $row['name']; ?> </td>
				<td> <?php echo $row['description']; ?> </td>
				<td> <?php echo $taka; ?> </td>
			</tr>
		<?php
		}
		?>
		<tr class="totalcell">
					<td colspan="2"> Total </td>
					<td> <?php echo $total_taka; ?> </td>
				</tr>
			</table>
	<?php } ?>	