<?php
	include_once('../connection/connect.php');	
	
	if( true ){
		$vw_product = $_POST['vw_product'];
		$vw_memo = $_POST['vw_memo'];

		$query = "SELECT * FROM inv_invoice WHERE memo_no='".$vw_memo."' AND products='".$vw_product."' ";
		
		$result = mysqli_query($link, $query);
		$row=mysqli_fetch_array($result);
		$arr = array();
		$arr[0] = $row['date'];
		$arr[1] = $row['id_no'];
		$arr[2] = $row['name'];
		$arr[3] = $row['total_taka'];
		$arr[4] = $row['advance'];
		$arr[5] = $row['due'];
		$arr[6] = $row['bkash'];
		
		echo json_encode($arr);
		exit();
	}
	
?>