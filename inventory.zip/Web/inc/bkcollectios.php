<?php
include_once('../connection/connect.php');	
	
if( !empty($_POST['bk_date']) && !empty($_POST['bk_product']) ){
	
		$bk_date = $_POST['bk_date'];
		$bk_product = $_POST['bk_product'];

		$query = "SELECT * FROM inv_bkash WHERE bkdate='".$bk_date."' AND products='".$bk_product."' ";
		?>
			<table>
				<div class="tablef">
				<tr class="sp">
					<th>ID No</th>
					<th>Memo No</th>
					<th>Taka</th>
					<th>Mobile</th>
				</tr>
				</div>

		<?php
		$result = mysqli_query($link, $query);
		$total_taka=0.0;
		$total_takat = 0.0;
		while( $row=mysqli_fetch_array($result) ){
			$total_taka = $row['bktaka'];
			$mobile = $row['bkmobile'];
			$total_takat = $total_takat+$total_taka;
			$memo = $row['bkmemo'];
		?>
			<tr>
				<td> <?php echo $row['bkid']; ?> </td>
				<td> <?php echo $memo ?> </td>
				<td> <?php echo $total_taka; ?> </td>
				<td> <?php echo $mobile; ?> </td>
				

			</tr>
		<?php
		}
		?>
		<tr class="totalcell">
					<td colspan="3"> Total </td>
					<td> <?php echo $total_takat; ?> </td>
				</tr>
			</table>
	<?php } ?>	