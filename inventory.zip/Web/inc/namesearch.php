<?php
	include_once('../connection/connect.php');	
	
	
		$id = $_POST['id'];

		$mql = "SELECT * FROM inv_invoice WHERE id_no='".$id."' ";
		$res = mysqli_query($link, $mql);
		$row = mysqli_fetch_array($res);
		echo $row['name'];
	
?>