<?php
	include_once('../connection/connect.php');	

		$mql = "DELETE FROM inv_users WHERE username='".$del_product."' AND id_no='".$del_id."' AND memo_no='".$del_memo."' ";
		if( mysqli_query($link, $mql) ){
			echo "DELETED";
		}else{
			echo "SOmeThing Went Wrong";
		}

	
?>