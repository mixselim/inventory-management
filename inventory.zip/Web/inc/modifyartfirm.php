<?php
	include_once('../connection/connect.php');	
	
	if( !empty($_POST['art_id']) && !empty($_POST['art_office']) && !empty($_POST['art_propitor']) && !empty($_POST['art_address']) && !empty($_POST['art_telephone']) && !empty($_POST['art_mobile']) && !empty($_POST['art_email']) ){
	
		$art_id = $_POST['art_id'];
		$art_office = $_POST['art_office'];
		$art_propitor = $_POST['art_propitor'];
		$art_address = $_POST['art_address'];
		$art_telephone = $_POST['art_telephone'];
		$art_mobile = $_POST['art_mobile'];
		$art_email = $_POST['art_email'];
		
		$mql = "UPDATE inv_artfirm SET office_name='".$art_office."', propitor_name='".$art_propitor."', address='".$art_address."', telephone='".$art_telephone."', mobile='".$art_mobile."', email='".$art_email."' WHERE id_no='".$art_id."'  ";
		if( mysqli_query($link, $mql) ){
			echo "UPDATEED.";
		}else{
			echo "SOmeThing Went Wrong";
		}
	}else{
		echo "All Fields Are Required.";
	}
	
?>