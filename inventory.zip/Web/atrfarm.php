<?php
	include_once("header.php");
	$pro = "";
	if( !empty($_GET['tag']) ){
		$pro = $_GET['tag'];
	}
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;"><?php echo $pro; ?></h3>
							<div class="col-md-4 page2_main_body_left fix">

								<h5>Art Fram</h5>
								<p>
								  <a href="artfarmlist.php"><button type="button" class="btn btn-primary">View Art Fram List</button></a>
								</p>
								<p>
								  <button type="button" class="btn btn-primary delart">Delete Unused Art Farm</button>
								</p>


							<div class="col-md-12 page2_main_body_right fix">
								<div class="delform">
								<h4 style="color:red;font-weight:bold;">Delete Art Farm</h4>

								<form class="form-horizontal">
								  <div class="form-group">							    
								    <div class="col-sm-10">
								      <input type="text" class="form-control" id="inputEmail3" placeholder="ID No">
								    </div>
								  </div>

								   <div class="form-group">
								    
								    <div class="col-sm-10">
								      <button type="submit" class="btn btn-default">DELETE</button>
								     
								    </div>
								  </div>

								  
								
								</form>	
								</div>

							</div>


							</div>

							
							<div class="col-md-8 page3_main_body_right fix">
								<h4>New Art Farm</h4>
								

								<form class="form-horizontal">
								  
								<div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="at_id" placeholder="ID No">
								    </div>
								  </div>
								  
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Office Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="at_office" placeholder="Office Name">
								    </div>
								  </div>
								
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Propitor Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="at_propitor" placeholder="Propitor Name">
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Address</label>
								    <div class="col-sm-9">
								      <textarea type="text" class="form-control" id="at_address" placeholder="Address"></textarea>
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Telephone</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="at_telephone" placeholder="Telephone">
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Mobile</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="at_mobile" placeholder="Mobile">
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Email</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="at_email" placeholder="Email">
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3"></label>
								    <div class="col-sm-9">
								      <input type="button" name="at_submit" id="at_submit" class="btn btn-default" value="ADD" />
								      
								    </div>
								  </div>
									<div class="form-group">
										<label for="inputEmail3" class="col-sm-3"></label>
										<div class="col-sm-9">
										  <span id="at_errormsg"></span>
										  <span id="at_savemsg"></span>
										  
										</div>
									  </div>
								  
								</form>
								
								
							</div>

			

						</div>

					</div>

			    </div>

			</div>
		<script type="text/javascript"><!-- New Artfarm -->
			$(document).ready(function(){
				$("#at_submit").click(function(){
					var at_id = $('#at_id').val();
					var at_office = $('#at_office').val();
					var at_propitor = $('#at_propitor').val();
					var  at_address = $('#at_address').val();
					var at_telephone = $('#at_telephone').val();
					var at_mobile = $('#at_mobile').val();
					var at_email = $('#at_email').val();
					
					if( at_id=='' || at_office=='' || at_propitor=='' || at_address=='' || at_telephone=='' || at_mobile=='' || at_email=='' ){
						$('#at_savemsg').html("");
						$('#at_errormsg').html("All Fields are required!");
					}else{
						$('#at_errormsg').html("");
						$.ajax({
							url:'inc/newartfarm.php',
							method:'POST',
							data:{at_id:at_id, at_office:at_office, at_propitor:at_propitor, at_address:at_address, at_telephone:at_telephone, at_mobile:at_mobile, at_email:at_email},
							success:function(data){
								$('form').trigger('reset');
								$('#at_savemsg').fadeIn().html(data);
								setTimeout( function(){
									$('#at_savemsg').fadeOut('slow');
								},2000 );
							}
						});
					}
				});
			});
		</script>
	</div>

</body>
</html>