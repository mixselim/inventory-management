<?php
include_once('connection/connect.php');
include_once('functions.php'); 
if(!islogin()){
		header('location:login.php');
	}	
	
?>
<!DOCTYPE html>
<html>
	
	<header>
		<title>STAR GRAPHICS & DIGITAL PRINT</title>
		<link rel="stylesheet" href="css/print.css" />
	</header>
	<body>
		<div class="p_container">
		<?php
			$mql = "SELECT * FROM inv_setings";
			$res = mysqli_query($link, $mql);
			while( $row = mysqli_fetch_array($res) ){
				$p_he = $row['p_header'];
				$p_fo = $row['p_footer'];
			}
		?>
			<div class="p_header">
				<?php echo $p_he; ?>
			</div>
			<div class="tabletitle">
			<?php 
				if( isset($_POST['tabletitle']) ){
					echo $_POST['tabletitle'];
				}else{
					echo "<h3 style='text-align:center;' >Table not found...</h3>";
				}
			?>
			</div>
			<div class="p_body">
				<?php 
					if( isset($_POST['print']) ){
						echo $_POST['print'];
					}else{
						echo "<h3 style='text-align:center;' >Table not found...</h3>";
					}
				?>
			</div>
			<div class="p_footer">
				<?php 
					echo $p_fo;
				?>
			</div>
			<div class="print_a">
				<a href="#" onclick="window.print();">print</a>
			</div>
		</div>
	</body>
</html>