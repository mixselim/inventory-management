<?php
	include_once("header.php");

 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h2 style="height:50px;"></h2>
							<?php 
								$office_name="";
								$propitor_name="";
								$address="";
								$telephone="";
								$mobile="";
								$email="";
								$id="";
								if( !empty($_GET['st']) && !empty($_GET['id']) ){
									$st = $_GET['st'];
									$id = $_GET['id'];
									if(strcmp($st,'modi')==0){
										$query = "SELECT * FROM inv_artfirm WHERE id_no='".$id."' ";
										$res = mysqli_query($link, $query);
										$row = mysqli_fetch_array($res);
										
										$office_name = $row['office_name'];
										$propitor_name = $row['propitor_name'];
										$address = $row['address'];
										$telephone = $row['telephone'];
										$mobile = $row['mobile'];
										$email = $row['email'];
									}else{

									}
								}
							?>
							<div class="col-md-12 page3_main_body_left fix">
								 <h4>Modify Art Farm</h4>
								<form class="form-horizontal">

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_id" placeholder="ID No" readonly value="<?php echo $id; ?>" />
								    </div>
								  </div>
								  
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Office Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_office" placeholder="Office Name" value="<?php echo $office_name; ?>" />
								    </div>
								  </div>
								

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Propitor Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_propitor" placeholder="Propitor Name" value="<?php echo $propitor_name; ?>" />
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Address</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_address" placeholder="Address" value="<?php echo $address; ?>" />
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Telephone</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_telephone" placeholder="Telephone" value="<?php echo $telephone; ?>" />
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Mobile</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_mobile" placeholder="Mobile" value="<?php echo $mobile; ?>" />
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Email</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="art_email" placeholder="Email" value="<?php echo $email; ?>" />
								    </div>
								  </div>
								<div class="form-group">
									<label for="inputEmail3" class="col-sm-3"></label>
									<div class="col-sm-9">
									  <input type="button" id="art_modi" class="btn btn-default" value="Update"/>
									 
									</div>
									<div>
										<span id="art_errormsg"></span>
										<span id="art_success"></span>
									</div>
								 </div>				  
								</form>						
							</div>
						</div>
					</div>
			    </div>
			</div>	
	</div>

	<script type="text/javascript"> <!-- New Invoice -->
		$(document).ready(function(){
			$("#art_modi").click(function(){
				var art_id = $('#art_id').val();
				var art_office = $('#art_office').val();
				var art_propitor = $('#art_propitor').val();
				var art_address = $('#art_address').val();
				var art_telephone = $('#art_telephone').val();
				var art_mobile = $('#art_mobile').val();
				var art_email = $('#art_email').val();
				
				if( art_id=='' || art_office=='' || art_propitor=='' || art_address=='' || art_telephone=='' || art_mobile=='' || art_email=='' ){
					$('#art_errormsg').html("All Fields are required!");
				}else{
					$('#art_errormsg').html("");
					$.ajax({
						url:'inc/modifyartfirm.php',
						method:'POST',
						data:{art_id:art_id, art_office:art_office, art_propitor:art_propitor, art_address:art_address, art_telephone:art_telephone, art_mobile:art_mobile, art_email:art_email},
						success:function(data){
							$('#art_success').fadeIn().html(data);
							setTimeout( function(){
								$('#art_success').fadeOut('slow');
							},2000 );
						}
					});
				}
			});
		});
	</script>
	
</body>
</html>