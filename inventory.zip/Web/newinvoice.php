<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;"><?php echo $pro; ?></h3>
							<div class="col-md-6 page3_main_body_left fix">
								<form class="form-horizontal leftform">
								  <div class="form-group p3date">
								    <label for="inputEmail3" class="col-sm-3 control-label">Date *</label>
								    <div class="col-sm-9">
								      <input type="date" class="form-control date" id="indate" name="indate" placeholder="Date" />
								    </div>
								  </div>
								<div id="newindate"></div>
								  <h4>New Invoice</h4>
								<div class="inwraper">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="inidno" name="inidno" placeholder="ID No" onkeyup="searchname();" />
								    </div>
								  </div>
								  
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="inname" name="inname" placeholder="Name">
								    </div>
								  </div>
								
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Memo No *</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="inmemono" name="inmemono" placeholder="Memo No">
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Total Take *</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="intotaltaka" name="intotaltaka" placeholder="Total Take" onkeyup="cal_due();" />
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Advance</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="inadvance" name="inadvance" placeholder="Advance" onkeyup="cal_due();" />
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Due</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="indue" name="indue" placeholder="Due" readonly />
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Bkash *</label>
								    <div class="col-sm-9">
								      <select name="inbkash" id="inbkash">
										<option value="yes">YES</option>
										<option value="no">NO</option>
									  </select>
								    </div>
								  </div>
								  <div><input type="hidden" name="inproduct" id="inproduct" value="<?php echo $pro; ?>"/></div>
								<div class="form-group">
								    <label for="inputEmail3" class="col-sm-3"></label>
								    <div class="col-sm-9">
								      <input type="button" id="inadd" class="btn btn-default" value="ADD"/>
								     
								    </div>
								 </div>
								  <div>
									<span id="errormsg" ></span>
									<span id="savemsg"></span>
								  
								  </div>
								</div>
								</form>
								
								
							</div>

							
							<div class="col-md-6 page3_main_body_right fix">
								<h4>Daily Due Collection</h4>

								<form class="form-horizontal">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="duid" placeholder="ID No">
								    </div>
								  </div>
								
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Memo No *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="dumemo" placeholder="Memo No">
								    </div>
								    <div class="col-sm-3">
								      <input type="button" value="ADD" id="duadd" class="btn btn-default" />
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Taka *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="dutaka" placeholder="Taka">
								    </div>
								  </div>
									<div>
										<span id="duerrormsg" ></span>
										<span id="dusavemsg" ></span>
									</div>
								
								</form>	

							</div>

							<div class="col-md-6 page3_main_body_right fix">
								<h4> Daily Expense </h4>

								<form class="form-horizontal">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Name *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="exname" placeholder="Name">
								    </div>
								  </div>
								
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Descriptions</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="exdes" placeholder="Descriptions">
								    </div>
								    <div class="col-sm-3">
								      <input type="button" value="ADD" id="exadd" class="btn btn-default" />
								     
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Taka *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="extaka" placeholder="Taka">
								    </div>
								  </div>
									<div>
										<span id="exerrormsg" ></span>
										<span id="exsavemsg" ></span>
									</div>
								
								</form>	
								 
							</div>

							<div class="col-md-6 page3_main_body_right fix">
								
								<h4>bKash Collection</h4>

								<form class="form-horizontal">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="bkid" placeholder="ID No">
								    </div>
								  </div>
								
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Memo No *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="bkmemo" placeholder="Memo No">
								    </div>
								    <div class="col-sm-3">
								      <input type="button" id="bkadd" class="btn btn-default" value="ADD" />
								     
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Taka *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="bktaka" placeholder="Taka">
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Mobile NO. *</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" id="bkmobile" placeholder="Mobile">
								    </div>
								  </div>
								<div>
									<span id="bkerrormsg" ></span>
									<span id="bksavemsg" ></span>
								</div>
								</form>	
								 
							</div>

						</div>

					</div>

			    </div>

			</div>
	</div>
	<script> <!-- Calculate Due -->
		function cal_due(){
			$totaltaka = $('#intotaltaka').val();
			$inadvance = $('#inadvance').val();
			$sub = $totaltaka-$inadvance;
			$('#indue').val($sub);
		}
	</script>
	
	<script>
		$(document).ready(function() {
				$('#indate').Zebra_DatePicker({
						container: $('#newindate')
					});
				
			 });
	 </script>

	 
	 <script type="text/javascript">
		$(document).ready(function(){
			$(".Zebra_DatePicker_Icon").click(function(){
				$('.dp_visible').attr('style', '');
			});
			$("#indate").click(function(){
				$('.dp_visible').attr('style', '');
			});
		});		

	</script>

	
	
	<script type="text/javascript"><!-- New Invoice -->
		$(document).ready(function(){
			$("#inadd").click(function(){
				var inproduct = $('#inproduct').val();
				var indate = $('#indate').val();
				var inidno = $('#inidno').val();
				var inname = $('#inname').val();
				var inmemono = $('#inmemono').val();
				var intotaltaka = $('#intotaltaka').val();
				var inadvance = $('#inadvance').val();
				var indue = $('#indue').val();
				var inbkash = $('#inbkash').val();
				if( inproduct=='' || indate=='' || inname=='' || inmemono=='' || intotaltaka=='' || inadvance=='' || indue=='' || inbkash=='' ){
					$('#savemsg').html("");
					$('#errormsg').html("All Fields are required!");
				}else{
					$('#errormsg').html("");
					$.ajax({
						url:'inc/invoice.php',
						method:'POST',
						data:{inproduct:inproduct, indate:indate, inidno:inidno, inname:inname, inmemono:inmemono, intotaltaka:intotaltaka, inadvance:inadvance, indue:indue, inbkash:inbkash},
						success:function(data){
							$('form').trigger('reset');
							$('#savemsg').fadeIn().html(data);
							setTimeout( function(){
								$('#savemsg').fadeOut('slow');
							},2000 );
						}
					});
				}
			});
		});
	</script>
	
	<script type="text/javascript"><!-- Daily Due Collections -->
		$(document).ready(function(){
			$("#duadd").click(function(){
				var inproduct = $('#inproduct').val();
				var indate = $('#indate').val();
				var duid = $('#duid').val();
				var dumemo = $('#dumemo').val();
				var dutaka = $('#dutaka').val();
				
				if( inproduct=='' || indate=='' || duid=='' || dumemo=='' || dutaka=='' ){
					$('#dusavemsg').html("");
					$('#duerrormsg').html("All Fields are required!");
				}else{
					$('#duerrormsg').html("");
					$.ajax({
						url:'inc/ducollections.php',
						method:'POST',
						data:{inproduct:inproduct, indate:indate, duid:duid, dumemo:dumemo, dutaka:dutaka},
						success:function(data){
							$('form').trigger('reset');
							$('#dusavemsg').fadeIn().html(data);
							setTimeout( function(){
								$('#dusavemsg').fadeOut('slow');
							},2000 );
						}
					});
				}
			});
		});
	</script>
	
	<script type="text/javascript"><!-- Daily Expense -->
		$(document).ready(function(){
			$("#exadd").click(function(){
				var indate = $('#indate').val();
				var exname = $('#exname').val();
				var exdes = $('#exdes').val();
				var extaka = $('#extaka').val();
				
				if( indate=='' || exname=='' || extaka=='' ){
					$('#exsavemsg').html("");
					$('#exerrormsg').html("All Fields are required!");
				}else{
					$('#exerrormsg').html("");
					$.ajax({
						url:'inc/expense.php',
						method:'POST',
						data:{indate:indate, exname:exname, exdes:exdes, extaka:extaka},
						success:function(data){
							$('form').trigger('reset');
							$('#exsavemsg').fadeIn().html(data);
							setTimeout( function(){
								$('#exsavemsg').fadeOut('slow');
							},2000 );
						}
					});
				}
			});
		});
	</script>
	
	<script type="text/javascript"><!-- bkash -->
		$(document).ready(function(){
			$("#bkadd").click(function(){
				var inproduct = $('#inproduct').val();
				var indate = $('#indate').val();
				var bkid = $('#bkid').val();
				var bkmemo = $('#bkmemo').val();
				var bktaka = $('#bktaka').val();
				var bkmobile = $('#bkmobile').val();
				
				if( inproduct=='' || indate=='' || bkid=='' || bkmemo=='' || bktaka=='' ||  bkmobile==''){
					$('#bksavemsg').html("");
					$('#bkerrormsg').html("All Fields are required!");
					
				}else{
					$('#bkerrormsg').html("");
					$.ajax({
						url:'inc/bkash.php',
						method:'POST',
						data:{inproduct:inproduct, indate:indate, bkid:bkid, bkmemo:bkmemo, bktaka:bktaka, bkmobile:bkmobile},
						success:function(data){
							$('form').trigger('reset');
							$('#bksavemsg').fadeIn().html(data);
							setTimeout( function(){
								$('#bksavemsg').fadeOut('slow');
							},2000 );
						}
					});
				}
			});
		});
	</script>
	
	
		<script type="text/javascript"> <!-- Search Artfirm name -->
			function searchname(){
					var id = $('#inidno').val();
					
					if( id==''){
						
					}else{
						$.ajax({
							url:'inc/namesearch.php',
							method:'POST',
							data:{id:id},
							success:function(data){
								$('#inname').val(data);

							}
						});
					}
			}
		</script>
</body>
</html>