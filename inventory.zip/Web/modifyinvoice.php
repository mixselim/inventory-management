<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3><?php echo $pro; ?></h3>
							<div class="col-md-12 page3_main_body_left fix">
								 <h4>Modify Invoice</h4>
								<form class="form-horizontal">
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Memo No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="modi_smemo" placeholder="Memo No" required/>
								    </div>

								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3"></label>
								    <div class="col-sm-9">
								       <input type="button" id="modi_edit" class="btn btn-default" value="Edit" />
								    </div>
								  </div>
								</form>



								<form class="form-horizontal">

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">ID No</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="modi_id" placeholder="ID No">
								    </div>
								  </div>
								  
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Name</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="modi_name" placeholder="Name">
								    </div>
								  </div>
								

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Total Take</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="modi_taka" placeholder="Total Take" onkeyup="cal_due();" />
								    </div>
								  </div>

								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Advance</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="modi_advance" placeholder="Advance" onkeyup="cal_due();" />
								    </div>
								  </div>

								   <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Due</label>
								    <div class="col-sm-9">
								      <input type="text" class="form-control" id="modi_due" placeholder="Due" readonly />
								    </div>
								  </div>
								  
								  <div><input type="hidden" name="modi_product" id="modi_product" value="<?php echo $pro; ?>" /></div>
									
									<div class="form-group">
										<label for="inputEmail3" class="col-sm-3"></label>
										<div class="col-sm-9">
										  <input type="button" id="modi_add" class="btn btn-default" value="Update"/>
										 
										</div>
										<div>
											<span id="modi_errormsg"></span>
											<span id="modi_success"></span>
										</div>
									 </div>				  
								</form>						
							</div>
						</div>
					</div>
			    </div>
			</div>	
	</div>
	<script> <!-- Calculate Due -->
		function cal_due(){
			$totaltaka = $('#modi_taka').val();
			$inadvance = $('#modi_advance').val();
			$sub = $totaltaka-$inadvance;
			$('#modi_due').val($sub);
		}
	</script>
	
	
	
	<script type="text/javascript"> <!-- New Invoice -->
		$(document).ready(function(){
			$("#modi_add").click(function(){
				var modi_smemo = $('#modi_smemo').val();
				
				var modi_product = $('#modi_product').val();
				var modi_id = $('#modi_id').val();
				var modi_name = $('#modi_name').val();
				var modi_taka = $('#modi_taka').val();
				var modi_advance = $('#modi_advance').val();
				var modi_due = $('#modi_due').val();
				
				if( modi_smemo=='' || modi_product=='' || modi_id=='' || modi_name=='' || modi_taka=='' || modi_advance=='' || modi_due=='' ){
					$('#modi_errormsg').html("All Fields are required!");
				}else{
					$('#modi_errormsg').html("");
					$.ajax({
						url:'inc/modify.php',
						method:'POST',
						data:{modi_smemo:modi_smemo, modi_product:modi_product, modi_id:modi_id, modi_name:modi_name, modi_taka:modi_taka, modi_advance:modi_advance, modi_due:modi_due},
						success:function(data){
							$('form').trigger('reset');
							$('#modi_success').fadeIn().html(data);
							setTimeout( function(){
								$('#modi_success').fadeOut('slow');
							},2000 );
						}
					});
				}
			});
		});
	</script>
	
		<script type="text/javascript"><!-- Modify invoice search -->
			$(document).ready(function(){
				$("#modi_edit").click(function(){
					
				});
			});
		</script>
	
</body>
</html>