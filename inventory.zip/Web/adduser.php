<?php
	include_once("header.php");
	$uinfo = "";
	if(isset($_POST['submit'])){
		$name = $_POST['username'];
		$pass = $_POST['password'];
		$usertype = $_POST['usertype'];
		$pass = md5($pass);
		
		$mql = "SELECT * FROM inv_users WHERE username='".$name."' ";
		$res = mysqli_query($link, $mql);
		$numrow = mysqli_fetch_row($res);
		if($numrow>0){
			$uinfo="User already exits.";
		}else{
			$mql = "INSERT INTO inv_users(id, username, password, type) VALUES('', '".$name."', '".$pass."', '".$usertype."' ) ";
		$res = mysqli_query($link, $mql);
			$uinfo="user successfully added.";
		}
	}
	
 ?>
			<div class="clear"></div>
			<div class="main_body fix">
				<div class="container">
					<div class="row fix users">
						<div class="col-md-4 fix">
							<div class="usermenu">
								<ul>
									<li><a href="users.php">User List</a></li>
									<li><a href="">Add New</a></li>
								</ul>
							</div>
						</div>
						<div class="col-md-8 fix userlist">
							<div style="height:30px;text-align:center;">
								<p><?php echo $uinfo; ?></p>
							</div>
							<form class="form-horizontal" action="" method="post" >
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">User Name</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" name="username" placeholder="User Name" required />
								    </div>
								  </div>
								
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Password</label>
								    <div class="col-sm-6">
								      <input type="text" class="form-control" name="password" placeholder="Password" required />
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 control-label">Type</label>
								    <div class="col-sm-6">
										<select name="usertype" id="">
											<option value="1"> Super User </option>
											<option value="2"> User </option>
										</select>
								    </div>
								  </div>
								  <div class="form-group">
								    <label for="inputEmail3" class="col-sm-3 "></label>
								    <div class="col-sm-6">
								      <input type="submit" class="form-control" name="submit" value="Add New" />
								    </div>
								  </div>
							</form>	
						</div>
					</div>
			    </div>
			</div>
	</div>

</body>
</html>