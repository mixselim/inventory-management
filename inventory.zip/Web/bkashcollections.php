<?php
	include_once("header.php");
 ?>
			
			<div class="clear"></div>

			<div class="main_body fix">

				<div class="container">

					<div class="row fix">

						<div class="col-md-12 page3_main_body fix">

							<h3 style="text-transform: capitalize;"><?php echo $pro; ?></h3>
							<header class="tableheader">
								<div class="row fix">
									<div class="col-md-6 fix">
										<div class="dailysales">
										<p>
											bKash Collections
										</p>
										</div>
									</div>
									<div class="col-md-6 fix">
										<div class="sdate">
											<form>
												<input type="date" name="viewsdate" id="bk_date" placeholder="Date: yyyy-mm-dd" />
												<input type="button" name="viewssubmit" value="View" id="bk_submit" />
												<input type="hidden" id="bk_product" value="<?php echo $pro; ?>" />
											</form>
										</div>
										<div id="bkshow"></div>
									</div>
								</div>
							</header>
							<div class="salestable" id="bk_table" >
								<!-- Table Here -->
								<?php
									$today = date("Y-m-d");
									if( $today !='' ){

											$query = "SELECT * FROM inv_bkash WHERE bkdate='".$today."' AND products='".$pro."' ";
											?>
												<table>
													<div class="tablef">
													<tr class="sp">
														<th>ID No</th>
														<th>Memo No</th>
														<th>Taka</th>
														<th>Mobile</th>
													</tr>
													</div>

											<?php
											$result = mysqli_query($link, $query);
											$total_taka=0.0;
											$total_takat = 0.0;
											while( $row=mysqli_fetch_array($result) ){
												$total_taka = $row['bktaka'];
												$mobile = $row['bkmobile'];
												$total_takat = $total_takat+$total_taka;
												$memo = $row['bkmemo'];
											?>
												<tr>
													<td> <?php echo $row['bkid']; ?> </td>
													<td> <?php echo $memo ?> </td>
													<td> <?php echo $total_taka; ?> </td>
													<td> <?php echo $mobile; ?> </td>
													

												</tr>
											<?php
											}
											?>
											<tr class="totalcell">
														<td colspan="3"> Total </td>
														<td> <?php echo $total_takat; ?> </td>
													</tr>
												</table>
										<?php } ?>	
							</div>
							<div class="salestfooter">
								<div class="row fix">
									<div class="col-md-12">
										<form action="print.php" method="post" >
											<input type="hidden" name="print" id="print" />
											<input type="hidden" name="tabletitle" value="bKash Collections" />
											<button type="submit" class="pbtn">Print</button>
										</form>
									</div>
								</div>
							</div>
						</div>

					</div>

			    </div>

			</div>
	</div>
	<script type="text/javascript">
		$(document).ready(function() {
			var pval = document.getElementById("bk_table").innerHTML;
			document.getElementById("print").value = pval;
		});
	</script>
	
		<script>
		$(document).ready(function() {
				$('#bk_date').Zebra_DatePicker({
					container: $('#bkshow')
				});
				$('.Zebra_DatePicker').attr('style', '');
				$('.Zebra_DatePicker_Icon').attr('style', 'top:0px;right:0px;');
			 });
	 </script>
	  <script type="text/javascript">
	$(document).ready(function(){
		$(".Zebra_DatePicker_Icon").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
		$("#bk_date").click(function(){
			$('.Zebra_DatePicker').attr('style', '');
		});
	});		

</script>
	

	<script type="text/javascript"> 	<!-- Daily Sales Views -->
		$(document).ready(function(){
			$("#bk_submit").click(function(){
				var bk_date = $('#bk_date').val();
				var bk_product = $('#bk_product').val();
				
				if( bk_date=='' || bk_product=='' ){
					alert("Something Went Wrong!");
				}else{
					$.ajax({
						url:'inc/bkcollectios.php',
						method:'POST',
						data:{bk_date:bk_date, bk_product:bk_product},
						success:function(data){
							 $("#bk_table").html(data);
						}
					});
				}
				var pval = document.getElementById("bk_table").innerHTML;
				document.getElementById("print").value = pval;
			});
		});
	</script>
</body>
</html>