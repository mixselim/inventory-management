<?php 
include_once('connection/connect.php');
include_once('functions.php'); 
	session_destroy();
	header('location: login.php');
?>